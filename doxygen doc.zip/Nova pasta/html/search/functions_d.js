var searchData=
[
  ['react_0',['react',['../structdoctest_1_1detail_1_1_result_builder.html#a03686f862471728c2980d72e02980213',1,'doctest::detail::ResultBuilder::react()'],['../structdoctest_1_1detail_1_1_message_builder.html#a3a65c5e39a0c04ae8e2a7c34997a2e4d',1,'doctest::detail::MessageBuilder::react()']]],
  ['realiza_5fpagamento_1',['realiza_pagamento',['../class_pagamento.html#adf65ea3b0f20647f08aff9ad183e0b7a',1,'Pagamento']]],
  ['registerexceptiontranslator_2',['registerExceptionTranslator',['../namespacedoctest.html#a8e23e6bb4c6982688652060dbe41385d',1,'doctest']]],
  ['registerexceptiontranslatorimpl_3',['registerExceptionTranslatorImpl',['../namespacedoctest_1_1detail.html#a3887426da16e0d12e6f0e270a767a6a5',1,'doctest::detail']]],
  ['registerreporter_4',['registerReporter',['../namespacedoctest.html#a9e878a811f7bf0a615b3a39de3004673',1,'doctest']]],
  ['registerreporterimpl_5',['registerReporterImpl',['../namespacedoctest_1_1detail.html#a828e011bb6028ab94eb14a3c7d8bd2c4',1,'doctest::detail']]],
  ['regtest_6',['regTest',['../namespacedoctest_1_1detail.html#a00f99edefb8490a8e2602d58c96431f4',1,'doctest::detail']]],
  ['remove_5fproduto_7',['remove_produto',['../class_carrinho.html#a197870542e62da8fbe58020153535b83',1,'Carrinho']]],
  ['render_8',['render',['../classecommerce_1_1ui_1_1_menu.html#ab8b42b4b596b7d784b7a0ba00af1f30c',1,'ecommerce::ui::Menu']]],
  ['report_5fquery_9',['report_query',['../structdoctest_1_1_i_reporter.html#ae7e30d1c2cd332094c66d39bf3a85e52',1,'doctest::IReporter']]],
  ['reportercreator_10',['reporterCreator',['../namespacedoctest_1_1detail.html#ac78a52271e895d8485356c4516a18685',1,'doctest::detail']]],
  ['result_11',['result',['../structdoctest_1_1detail_1_1_result.html#ae38382da1a2d2f8e33aebc7da15febc9',1,'doctest::detail::Result::Result()=default'],['../structdoctest_1_1detail_1_1_result.html#ae4d2e8633aedaffa31f5c8b8530f522c',1,'doctest::detail::Result::Result(bool passed, const String &amp;decomposition=String())']]],
  ['resultbuilder_12',['resultbuilder',['../structdoctest_1_1detail_1_1_result_builder.html#a135e00690002d376f3d050700a635680',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type=&quot;&quot;, const String &amp;exception_string=&quot;&quot;)'],['../structdoctest_1_1detail_1_1_result_builder.html#ab55660e3aaa5d8fccbe19360f65bb1f3',1,'doctest::detail::ResultBuilder::ResultBuilder(assertType::Enum at, const char *file, int line, const char *expr, const char *exception_type, const Contains &amp;exception_string)']]],
  ['return_5fquantidade_13',['return_quantidade',['../class_estoque.html#ae8b618712c2e69a449d88fec45f8fd00',1,'Estoque']]],
  ['rfind_14',['rfind',['../classdoctest_1_1_string.html#a6e22f4f3820de5ffdf82e0acc6646759',1,'doctest::String']]],
  ['run_15',['run',['../classdoctest_1_1_context.html#a8059b137ef41cbe6c5d8160806a3cc63',1,'doctest::Context']]]
];
