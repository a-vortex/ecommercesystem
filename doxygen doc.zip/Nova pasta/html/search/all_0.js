var searchData=
[
  ['4_0',['👨‍🎓INTEGRANTES - GRUPO 4',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
