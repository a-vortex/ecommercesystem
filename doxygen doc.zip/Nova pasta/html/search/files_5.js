var searchData=
[
  ['inicial_2ecpp_0',['inicial.cpp',['../inicial_8cpp.html',1,'']]]
];
