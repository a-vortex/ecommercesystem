var searchData=
[
  ['basic_5fistream_0',['basic_istream',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fostream_1',['basic_ostream',['../classstd_1_1basic__ostream.html',1,'std']]],
  ['binary_5fassert_2',['binary_assert',['../structdoctest_1_1detail_1_1_result_builder.html#aa920a0617a26939d7adcd1ba2dec0e85',1,'doctest::detail::ResultBuilder::binary_assert()'],['../namespacedoctest_1_1detail.html#a1e295c708d2de0e47ac89c1632211159',1,'doctest::detail::binary_assert()']]],
  ['binary_5fname_3',['binary_name',['../structdoctest_1_1_context_options.html#a0590006b4d10296c9a697e32ff886f74',1,'doctest::ContextOptions']]],
  ['blue_4',['Blue',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92aada3ad8958b1319450cc20f3f8e5e2d6',1,'doctest::Color']]],
  ['bright_5',['Bright',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a7659647d16a78c607f9bafaa207b9e07',1,'doctest::Color']]],
  ['brightgreen_6',['BrightGreen',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a016090b96620a42a63dadf0265977664',1,'doctest::Color']]],
  ['brightred_7',['BrightRed',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a236dfdbcd49d10dbf1a31f9e2947a671',1,'doctest::Color']]],
  ['brightwhite_8',['BrightWhite',['../namespacedoctest_1_1_color.html#a32e9eaf6013139846e848af6e6cf2b92a4f80853796b4875d61ff5e4ad138492e',1,'doctest::Color']]],
  ['buf_9',['buf',['../classdoctest_1_1_string.html#a7e031ced488588936a540eba26facf67',1,'doctest::String']]],
  ['busca_10',['Busca',['../class_busca.html',1,'']]],
  ['busca_2ecpp_11',['busca.cpp',['../busca_8cpp.html',1,'']]],
  ['busca_2ehpp_12',['busca.hpp',['../busca_8hpp.html',1,'']]]
];
