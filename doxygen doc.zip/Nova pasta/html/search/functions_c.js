var searchData=
[
  ['produto_0',['produto',['../class_produto.html#a9a95d8fbf6f40d699c54928a2276a2fe',1,'Produto::Produto(const std::string &amp;nome, const std::string &amp;descricao, const std::string &amp;tipo, const std::string preco)'],['../class_produto.html#a0305050fca8c424c43d3a642d69f11dd',1,'Produto::Produto(const Produto &amp;other)']]]
];
