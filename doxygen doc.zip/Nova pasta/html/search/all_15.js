var searchData=
[
  ['value_0',['value',['../structdoctest_1_1detail_1_1types_1_1true__type.html#a5ad232af56ff87690d552f77e0413f02',1,'doctest::detail::types::true_type::value'],['../structdoctest_1_1detail_1_1types_1_1false__type.html#a8580f67f4b223b10e49d93b959767f6d',1,'doctest::detail::types::false_type::value'],['../structdoctest_1_1detail_1_1types_1_1is__enum.html#a2ac322024808b91cda5ce1a42691ee07',1,'doctest::detail::types::is_enum::value'],['../structdoctest_1_1detail_1_1should__stringify__as__underlying__type.html#a0115e8b2c73fe1a0fc9f344a1374e2dd',1,'doctest::detail::should_stringify_as_underlying_type::value'],['../structdoctest_1_1_is_na_n.html#a6a490d3d5f5561bcf019fefc88291475',1,'doctest::IsNaN::value']]],
  ['version_1',['version',['../structdoctest_1_1_context_options.html#a08931527a9e5e634e64a336e5493a7c1',1,'doctest::ContextOptions']]]
];
