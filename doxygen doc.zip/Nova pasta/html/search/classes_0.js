var searchData=
[
  ['administrador_0',['Administrador',['../class_administrador.html',1,'']]],
  ['approx_1',['Approx',['../structdoctest_1_1_approx.html',1,'doctest']]],
  ['assertdata_2',['AssertData',['../structdoctest_1_1_assert_data.html',1,'doctest']]]
];
