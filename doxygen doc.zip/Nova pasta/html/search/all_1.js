var searchData=
[
  ['_5foptions_0',['_options',['../classecommerce_1_1ui_1_1_menu.html#aee4f81332b1361956d510219d52893c2',1,'ecommerce::ui::Menu']]],
  ['_5ftitle_1',['_title',['../classecommerce_1_1ui_1_1_menu.html#a0b3a43a8d9078bfc7def46896c0d9909',1,'ecommerce::ui::Menu']]]
];
