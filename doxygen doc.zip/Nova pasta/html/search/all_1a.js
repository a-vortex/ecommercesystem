var searchData=
[
  ['💭conceito_0',['💭CONCEITO',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];
