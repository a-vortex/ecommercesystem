var searchData=
[
  ['basic_5fistream_0',['basic_istream',['../classstd_1_1basic__istream.html',1,'std']]],
  ['basic_5fostream_1',['basic_ostream',['../classstd_1_1basic__ostream.html',1,'std']]],
  ['busca_2',['Busca',['../class_busca.html',1,'']]]
];
