var searchData=
[
  ['🚧arquitetura_20do_20projeto_0',['🚧ARQUITETURA DO PROJETO',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
