var searchData=
[
  ['addfilter_0',['addFilter',['../classdoctest_1_1_context.html#a60ad57a46c19db2b142468c3acac448a',1,'doctest::Context']]],
  ['adiciona_5fproduto_1',['adiciona_produto',['../class_carrinho.html#aa241e19465317f7a095995b83074947f',1,'Carrinho::adiciona_produto()'],['../class_estoque.html#a6018b975505afc335a73f395f84dc866',1,'Estoque::adiciona_produto()']]],
  ['adicionahistorico_2',['adicionaHistorico',['../class_cliente.html#ae1dd7766a4b9bb54411a4ba97d4cecc9',1,'Cliente']]],
  ['altera_5fpreco_3',['altera_preco',['../class_cupom.html#a8c6e417a06d5817654310b62f3a8124f',1,'Cupom']]],
  ['applycommandline_4',['applyCommandLine',['../classdoctest_1_1_context.html#ad55229220bf9ca74e6e0c6323bf672e1',1,'doctest::Context']]],
  ['approx_5',['Approx',['../structdoctest_1_1_approx.html#a86f0d1b44c1cf095697f23ccdab00802',1,'doctest::Approx']]],
  ['assertdata_6',['AssertData',['../structdoctest_1_1_assert_data.html#ae1f9906888c2dd06b6291ab196f5074e',1,'doctest::AssertData']]],
  ['assertstring_7',['assertString',['../namespacedoctest.html#a44bf1260a82383247d446170810493cf',1,'doctest']]],
  ['associaid_8',['associaID',['../class_produto.html#a769d0d9b9880ffc7a3c16ac1e373e1b2',1,'Produto']]],
  ['atualiza_5fendereco_9',['atualiza_endereco',['../class_usuario.html#a198eaed6558354c2fde2cbd7fcd47145',1,'Usuario']]],
  ['atualiza_5finfo_10',['atualiza_info',['../class_produto.html#ac1bfb216c517ec6c62747412193cc114',1,'Produto']]],
  ['atualiza_5fnomeusuario_11',['atualiza_nomeusuario',['../class_usuario.html#a9ad4ec114552b6dd3eb81eca7f949c1b',1,'Usuario']]],
  ['atualiza_5fquantidade_12',['atualiza_quantidade',['../class_estoque.html#af1b0900011a46c4a8172a8aaf6a07f77',1,'Estoque']]],
  ['atualiza_5ftelefone_13',['atualiza_telefone',['../class_usuario.html#a4fb1455d82af787883798b479f45c4eb',1,'Usuario']]],
  ['autenticacao_14',['Autenticacao',['../classecommerce_1_1ui_1_1_cadastro.html#a3c91f543618d03da80f94d2dad163852',1,'ecommerce::ui::Cadastro']]]
];
